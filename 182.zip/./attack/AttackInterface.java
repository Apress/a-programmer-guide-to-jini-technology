
public interface AttackInterface extends java.io.Serializable {
    
    public void attack() throws java.rmi.RemoteException; 
    
} // AttackInterface

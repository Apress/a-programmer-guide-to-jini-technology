
/**
 * AttackRegistrar.java
 *
 *
 * Created: Thu Jan  6 10:09:00 2000
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.discovery.LookupLocator;
import net.jini.core.lookup.ServiceID;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.event.EventRegistration;
import net.jini.core.event.RemoteEventListener;
import net.jini.core.lookup.ServiceRegistration;
import net.jini.core.lookup.ServiceItem;

public class AttackRegistrar implements ServiceRegistrar, java.io.Serializable {
    
    public AttackRegistrar() {
	
    }
    
    public Class[] getEntryClasses(ServiceTemplate tmpl) {
	return null;
    }
    
    public Object[] getFieldValues(ServiceTemplate tmpl,
		        int setIndex, java.lang.String field) {
	return null;
    } 
    
    public String[] getGroups() {
	return null;
    }
    
    public LookupLocator getLocator() {
	return null;
    }
    
    public ServiceID getServiceID() {
	return null;
    }
    
    public Class[] getServiceTypes(ServiceTemplate tmpl,
			    String prefix) {
	return null;
    }
    
    public Object lookup(ServiceTemplate tmpl) {
	return null; // stub
    }
    
    public ServiceMatches lookup(ServiceTemplate tmpl,
			  int maxMatches) {
	return null; //stub
    }
    
    public EventRegistration notify(ServiceTemplate tmpl,
			     int transitions,
			     RemoteEventListener listener,
			     java.rmi.MarshalledObject handback,
			     long leaseDuration) {
	return null;
    }

    public ServiceRegistration register(ServiceItem item,
				 long leaseDuration) {
	System.out.println("HA HA CAUGHT YOU");
	System.exit(1);
	return null;
    }

} // AttackRegistrar

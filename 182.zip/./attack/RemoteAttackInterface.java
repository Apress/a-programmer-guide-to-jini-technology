public interface RemoteAttackInterface 
	extends AttackInterface, java.rmi.Remote {

}


package common;

/**
 * NameEntry.java
 *
 *
 * Created: Mon Mar 29 11:36:25 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

public interface NameEntry  {
    
    public void show();
    
} // NameEntry

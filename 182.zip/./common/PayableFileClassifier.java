
package common;

/**
 * PayableFileClassifier.java
 *
 *
 * Created: Tue Aug  3 14:14:44 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

public interface PayableFileClassifier extends FileClassifier, Payable {
        
} // PayableFileClassifier

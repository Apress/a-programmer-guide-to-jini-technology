/*
 * File: ./corba/HelloApp/HelloHolder.java
 * From: Hello.idl
 * Date: Tue Aug 24 11:30:21 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.HelloApp;
public final class HelloHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public corba.HelloApp.Hello value;
    //	constructors 
    public HelloHolder() {
	this(null);
    }
    public HelloHolder(corba.HelloApp.Hello __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        corba.HelloApp.HelloHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = corba.HelloApp.HelloHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return corba.HelloApp.HelloHelper.type();
    }
}

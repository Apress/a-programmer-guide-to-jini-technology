/*
 * File: ./corba/HelloApp/_HelloStub.java
 * From: Hello.idl
 * Date: Tue Aug 24 11:30:21 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.HelloApp;
public class _HelloStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements corba.HelloApp.Hello {

    public _HelloStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:corba/HelloApp/Hello:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::corba::HelloApp::Hello::sayHello
    public String sayHello()
 {
           org.omg.CORBA.Request r = _request("sayHello");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }

};

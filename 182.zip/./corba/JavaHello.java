
/**
 * JavaHello.java
 *
 *
 * Created: Tue Aug 24 11:12:36 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */
package corba;

import java.io.Serializable;

public interface JavaHello extends Serializable {
    
    public String sayHello();
} // JavaHello

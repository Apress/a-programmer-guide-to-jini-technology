/*
 * File: ./corba/RoomBooking/MaxSlots.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public interface MaxSlots {
    final short value = (short) (8L);
};

/*
 * File: ./corba/RoomBooking/MeetingFactory.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public interface MeetingFactory
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    corba.RoomBooking.Meeting CreateMeeting(String purpose, String participants)
;
}

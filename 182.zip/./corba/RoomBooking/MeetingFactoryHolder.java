/*
 * File: ./corba/RoomBooking/MeetingFactoryHolder.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public final class MeetingFactoryHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public corba.RoomBooking.MeetingFactory value;
    //	constructors 
    public MeetingFactoryHolder() {
	this(null);
    }
    public MeetingFactoryHolder(corba.RoomBooking.MeetingFactory __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        corba.RoomBooking.MeetingFactoryHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = corba.RoomBooking.MeetingFactoryHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return corba.RoomBooking.MeetingFactoryHelper.type();
    }
}

/*
 * File: ./corba/RoomBooking/MeetingHelper.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public class MeetingHelper {
     // It is useless to have instances of this class
     private MeetingHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, corba.RoomBooking.Meeting that) {
        out.write_Object(that);
    }
    public static corba.RoomBooking.Meeting read(org.omg.CORBA.portable.InputStream in) {
        return corba.RoomBooking.MeetingHelper.narrow(in.read_Object());
    }
   public static corba.RoomBooking.Meeting extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, corba.RoomBooking.Meeting that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "Meeting");
      return _tc;
   }
   public static String id() {
       return "IDL:corba/RoomBooking/Meeting:1.0";
   }
   public static corba.RoomBooking.Meeting narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof corba.RoomBooking.Meeting)
            return (corba.RoomBooking.Meeting) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        corba.RoomBooking.Meeting result = new corba.RoomBooking._MeetingStub(dup);
        return result;
   }
}

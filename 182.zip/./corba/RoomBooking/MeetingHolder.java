/*
 * File: ./corba/RoomBooking/MeetingHolder.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public final class MeetingHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public corba.RoomBooking.Meeting value;
    //	constructors 
    public MeetingHolder() {
	this(null);
    }
    public MeetingHolder(corba.RoomBooking.Meeting __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        corba.RoomBooking.MeetingHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = corba.RoomBooking.MeetingHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return corba.RoomBooking.MeetingHelper.type();
    }
}

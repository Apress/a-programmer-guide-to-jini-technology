/*
 * File: ./corba/RoomBooking/NoMeetingInThisSlotHolder.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public final class NoMeetingInThisSlotHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public corba.RoomBooking.NoMeetingInThisSlot value;
    //	constructors 
    public NoMeetingInThisSlotHolder() {
	this(null);
    }
    public NoMeetingInThisSlotHolder(corba.RoomBooking.NoMeetingInThisSlot __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        corba.RoomBooking.NoMeetingInThisSlotHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = corba.RoomBooking.NoMeetingInThisSlotHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return corba.RoomBooking.NoMeetingInThisSlotHelper.type();
    }
}

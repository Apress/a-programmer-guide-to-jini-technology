/*
 * File: ./corba/RoomBooking/Room.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public interface Room
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    String name();
    corba.RoomBooking.Meeting[] View()
;
    void Book(corba.RoomBooking.Slot a_slot, corba.RoomBooking.Meeting a_meeting)
        throws corba.RoomBooking.SlotAlreadyTaken;
    void Cancel(corba.RoomBooking.Slot a_slot)
        throws corba.RoomBooking.NoMeetingInThisSlot;
}

/*
 * File: ./corba/RoomBooking/RoomPackage/MeetingsHelper.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking.RoomPackage;
public class MeetingsHelper {
     // It is useless to have instances of this class
     private MeetingsHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, corba.RoomBooking.Meeting[] that)  {
          {
              if (that.length != (corba.RoomBooking.MaxSlots.value)) {
                  throw new org.omg.CORBA.MARSHAL(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
              }
              for (int __index = 0 ; __index < (corba.RoomBooking.MaxSlots.value) ; __index += 1) {
                  corba.RoomBooking.MeetingHelper.write(out, that[__index]);
              }
          }
    }
    public static corba.RoomBooking.Meeting[] read(org.omg.CORBA.portable.InputStream in) {
          corba.RoomBooking.Meeting[] that;
          {
              that = new corba.RoomBooking.Meeting[(int) (corba.RoomBooking.MaxSlots.value)];
              for (int __index = 0 ; __index < (corba.RoomBooking.MaxSlots.value) ; __index += 1) {
                  that[__index] = corba.RoomBooking.MeetingHelper.read(in);
              }
          }
          return that;
    }
   public static corba.RoomBooking.Meeting[] extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, corba.RoomBooking.Meeting[] that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     a.type(type());
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_alias_tc(id(), "Meetings", org.omg.CORBA.ORB.init().create_array_tc((int) (corba.RoomBooking.MaxSlots.value), corba.RoomBooking.MeetingHelper.type()));
      return _tc;
   }
   public static String id() {
       return "IDL:corba/RoomBooking/Room/Meetings:1.0";
   }
}

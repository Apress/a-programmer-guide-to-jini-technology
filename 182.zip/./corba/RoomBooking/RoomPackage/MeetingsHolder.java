/*
 * File: ./corba/RoomBooking/RoomPackage/MeetingsHolder.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking.RoomPackage;
public final class MeetingsHolder
    implements org.omg.CORBA.portable.Streamable
{
    //	instance variable 
    public corba.RoomBooking.Meeting[] value;
    //	constructors 
    public MeetingsHolder() {
	this(null);
    }
    public MeetingsHolder(corba.RoomBooking.Meeting[] __arg) {
	value = __arg;
    }
    public void _write(org.omg.CORBA.portable.OutputStream out) {
        corba.RoomBooking.RoomPackage.MeetingsHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = corba.RoomBooking.RoomPackage.MeetingsHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return corba.RoomBooking.RoomPackage.MeetingsHelper.type();
    }
}

/*
 * File: ./corba/RoomBooking/Slot.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public final class Slot implements org.omg.CORBA.portable.IDLEntity {
     public static final int _am9 = 0,
	  		     _am10 = 1,
	  		     _am11 = 2,
	  		     _pm12 = 3,
	  		     _pm1 = 4,
	  		     _pm2 = 5,
	  		     _pm3 = 6,
	  		     _pm4 = 7;
     public static final Slot am9 = new Slot(_am9);
     public static final Slot am10 = new Slot(_am10);
     public static final Slot am11 = new Slot(_am11);
     public static final Slot pm12 = new Slot(_pm12);
     public static final Slot pm1 = new Slot(_pm1);
     public static final Slot pm2 = new Slot(_pm2);
     public static final Slot pm3 = new Slot(_pm3);
     public static final Slot pm4 = new Slot(_pm4);
     public int value() {
         return _value;
     }
     public static final Slot from_int(int i)  throws  org.omg.CORBA.BAD_PARAM {
           switch (i) {
             case _am9:
                 return am9;
             case _am10:
                 return am10;
             case _am11:
                 return am11;
             case _pm12:
                 return pm12;
             case _pm1:
                 return pm1;
             case _pm2:
                 return pm2;
             case _pm3:
                 return pm3;
             case _pm4:
                 return pm4;
             default:
	              throw new org.omg.CORBA.BAD_PARAM();
           }
     }
     private Slot(int _value){
         this._value = _value;
     }
     private int _value;
}

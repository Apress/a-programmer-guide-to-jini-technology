/*
 * File: ./corba/RoomBooking/SlotHelper.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public class SlotHelper {
     // It is useless to have instances of this class
     private SlotHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, corba.RoomBooking.Slot that)  {
    out.write_long(that.value());
    }
    public static corba.RoomBooking.Slot read(org.omg.CORBA.portable.InputStream in)  {
    return corba.RoomBooking.Slot.from_int(in.read_long());
    }
   public static corba.RoomBooking.Slot extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, corba.RoomBooking.Slot that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   private static final int _memberCount = 8;
   private static String[] _members = {
                  "am9",
                  "am10",
                  "am11",
                  "pm12",
                  "pm1",
                  "pm2",
                  "pm3",
                  "pm4"
   };
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_enum_tc(id(), "Slot", _members);
      return _tc;
   }
   public static String id() {
       return "IDL:corba/RoomBooking/Slot:1.0";
   }
}

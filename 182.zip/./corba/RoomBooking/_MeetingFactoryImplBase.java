/*
 * File: ./corba/RoomBooking/_MeetingFactoryImplBase.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public abstract class _MeetingFactoryImplBase extends org.omg.CORBA.DynamicImplementation implements corba.RoomBooking.MeetingFactory {
    // Constructor
    public _MeetingFactoryImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:corba/RoomBooking/MeetingFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("CreateMeeting", new java.lang.Integer(0));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // corba.RoomBooking.MeetingFactory.CreateMeeting
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _purpose = _orb().create_any();
              _purpose.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("purpose", _purpose, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _participants = _orb().create_any();
              _participants.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("participants", _participants, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              String purpose;
              purpose = _purpose.extract_string();
              String participants;
              participants = _participants.extract_string();
              corba.RoomBooking.Meeting ___result;
                            ___result = this.CreateMeeting(purpose, participants);
              org.omg.CORBA.Any __result = _orb().create_any();
              corba.RoomBooking.MeetingHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}

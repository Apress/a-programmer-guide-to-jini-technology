/*
 * File: ./corba/RoomBooking/_MeetingFactoryStub.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public class _MeetingFactoryStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements corba.RoomBooking.MeetingFactory {

    public _MeetingFactoryStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:corba/RoomBooking/MeetingFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::corba::RoomBooking::MeetingFactory::CreateMeeting
    public corba.RoomBooking.Meeting CreateMeeting(String purpose, String participants)
 {
           org.omg.CORBA.Request r = _request("CreateMeeting");
           r.set_return_type(corba.RoomBooking.MeetingHelper.type());
           org.omg.CORBA.Any _purpose = r.add_in_arg();
           _purpose.insert_string(purpose);
           org.omg.CORBA.Any _participants = r.add_in_arg();
           _participants.insert_string(participants);
           r.invoke();
           corba.RoomBooking.Meeting __result;
           __result = corba.RoomBooking.MeetingHelper.extract(r.return_value());
           return __result;
   }

};

/*
 * File: ./corba/RoomBooking/_MeetingStub.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public class _MeetingStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements corba.RoomBooking.Meeting {

    public _MeetingStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:corba/RoomBooking/Meeting:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	Implementation of attribute ::purpose
    public String purpose() {
           org.omg.CORBA.Request r = _request("_get_purpose");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	Implementation of attribute ::participants
    public String participants() {
           org.omg.CORBA.Request r = _request("_get_participants");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::corba::RoomBooking::Meeting::destroy
    public void destroy()
 {
           org.omg.CORBA.Request r = _request("destroy");
           r.send_oneway();
   }

};

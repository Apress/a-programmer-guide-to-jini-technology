/*
 * File: ./corba/RoomBooking/_RoomStub.java
 * From: RoomBooking.idl
 * Date: Wed Aug 25 11:30:25 1999
 *   By: idltojava Java IDL 1.2 Aug 11 1998 02:00:18
 */

package corba.RoomBooking;
public class _RoomStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements corba.RoomBooking.Room {

    public _RoomStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:corba/RoomBooking/Room:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	Implementation of attribute ::name
    public String name() {
           org.omg.CORBA.Request r = _request("_get_name");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::corba::RoomBooking::Room::View
    public corba.RoomBooking.Meeting[] View()
 {
           org.omg.CORBA.Request r = _request("View");
           r.set_return_type(corba.RoomBooking.RoomPackage.MeetingsHelper.type());
           r.invoke();
           corba.RoomBooking.Meeting[] __result;
           __result = corba.RoomBooking.RoomPackage.MeetingsHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::corba::RoomBooking::Room::Book
    public void Book(corba.RoomBooking.Slot a_slot, corba.RoomBooking.Meeting a_meeting)
        throws corba.RoomBooking.SlotAlreadyTaken {
           org.omg.CORBA.Request r = _request("Book");
           org.omg.CORBA.Any _a_slot = r.add_in_arg();
           corba.RoomBooking.SlotHelper.insert(_a_slot, a_slot);
           org.omg.CORBA.Any _a_meeting = r.add_in_arg();
           corba.RoomBooking.MeetingHelper.insert(_a_meeting, a_meeting);
           r.exceptions().add(corba.RoomBooking.SlotAlreadyTakenHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(corba.RoomBooking.SlotAlreadyTakenHelper.type())) {
                   throw corba.RoomBooking.SlotAlreadyTakenHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::corba::RoomBooking::Room::Cancel
    public void Cancel(corba.RoomBooking.Slot a_slot)
        throws corba.RoomBooking.NoMeetingInThisSlot {
           org.omg.CORBA.Request r = _request("Cancel");
           org.omg.CORBA.Any _a_slot = r.add_in_arg();
           corba.RoomBooking.SlotHelper.insert(_a_slot, a_slot);
           r.exceptions().add(corba.RoomBooking.NoMeetingInThisSlotHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(corba.RoomBooking.NoMeetingInThisSlotHelper.type())) {
                   throw corba.RoomBooking.NoMeetingInThisSlotHelper.extract(__userEx.except);
               }
           }
   }

};

package corba.RoomBookingImpl;

import org.omg.CORBA.*;
import corba.RoomBooking.*;

class MeetingFactoryImpl extends _MeetingFactoryImplBase {

    private ORB orb;

    // constructor
    MeetingFactoryImpl(String[] args) {

        try {
            // initialiase ORB
            orb = ORB.init(args, null);
        }
        catch(SystemException e) {
            System.out.println(e); }
    }
  
    // method
    public Meeting CreateMeeting(
        String purpose, String participants ) {

        MeetingImpl newMeeting = new MeetingImpl(purpose, participants);

        try {
            orb.connect( newMeeting );
        }
        catch(SystemException e) {
            System.out.println(e); }

        return newMeeting; 
    }
}

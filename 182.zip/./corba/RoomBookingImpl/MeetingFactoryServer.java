package corba.RoomBookingImpl;

import java.io.*;
import org.omg.CORBA.*;
// import com.wiley.compbooks.vogel.chapter8.naming.*;
import org.omg.CosNaming.*;
import corba.RoomBooking.*;

public class MeetingFactoryServer {

    public static void main(String[] args) {

        String str_name;

	/* out JN
        if( args.length != 0 ) {
	System.out.println("Usage: java MeetingFactoryServer");
	System.exit( 1 );
	}
	*/

        str_name = new String(
            "/BuildingApplications/MeetingFactories/MeetingFactory");

        try {
	    //initialise ORB
	    ORB orb = ORB.init( args, null );

            // initialise BOA
	    // BOA boa = orb.BOA_init();

	    // create the MeetingFactory object
	    MeetingFactoryImpl meeting_factory = new MeetingFactoryImpl(args);
	    orb.connect(meeting_factory);

	    // export the object reference
	    // boa.obj_is_ready(meeting_factory);

	    /*
            // register with naming service
            EasyNaming easy_naming =
                new EasyNaming( orb );

            // register with the CORBA Naming Service
            easy_naming.rebind_from_string( str_name, meeting_factory );
	    */
	    org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
	    NamingContext ncRef = NamingContextHelper.narrow(objRef);

	    NameComponent nc = new NameComponent(str_name, " ");
	    NameComponent path[] = {nc};
	    ncRef.rebind(path, meeting_factory);

	    // enter event loop
	    // boa.impl_is_ready();
	    Thread.sleep(1000000);
        }
	catch(Exception e) {
	    System.err.println(e);
        }
    }
}

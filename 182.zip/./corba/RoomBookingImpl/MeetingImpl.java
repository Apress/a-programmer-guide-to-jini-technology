package corba.RoomBookingImpl;

import org.omg.CORBA.*;
import corba.RoomBooking.*;

// MeetingImpl.java

class MeetingImpl extends _MeetingImplBase {

    private String purpose;
    private String participants;

    // constructor
    MeetingImpl( String purpose, String participants) {

	// initialise private variables
	this.purpose = purpose;
	this.participants = participants;
    }
  
    // attributes
    public String purpose() {
	return purpose;
    }

    public String participants() {
	return participants;
    }

    public void destroy() {
        _orb().disconnect( this );
    }
}

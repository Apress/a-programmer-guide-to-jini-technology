
/**
 * RemoteRoomBookingBridge.java
 *
 *
 * Created: Mon Aug 30 15:28:43 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package corba.RoomBookingImpl;

import java.rmi.Remote;
import corba.common.RoomBookingBridge;

public interface RemoteRoomBookingBridge extends RoomBookingBridge, Remote {
    
} // RemoteRoomBookingBridge

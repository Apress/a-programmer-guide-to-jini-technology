package corba.RoomBookingImpl;

import java.awt.*;
import java.awt.event.*;
import org.omg.CORBA.*;
import corba.RoomBooking.*;
// import RoomBooking.RoomPackage.*;

public class RoomBookingClientApplet
    extends java.applet.Applet {

private RoomBookingClient client;

    // override init method of Class Applet
    public void init() {

        // create a RoomBookingClient client -
        // using the applet constructor
        client = new RoomBookingClient( this );

        // initialiase the GUI
        client.init_GUI( this );

        // initialiase the Naming Service
        client.init_from_ns();

        // view existing bookings
        client.view();
    }
}

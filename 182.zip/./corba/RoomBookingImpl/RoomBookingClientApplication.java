package corba.RoomBookingImpl;

import java.awt.*;
import java.awt.event.*;
import org.omg.CORBA.*;
import corba.RoomBooking.*;
// import RoomBooking.RoomPackage.*;

public class RoomBookingClientApplication
    extends Frame
    implements WindowListener {

    private static RoomBookingClient client;

    // constructor
    RoomBookingClientApplication() {
        super( "Room Booking System" );
        addWindowListener( this );
        setSize( 350, 250 );
    }


    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    public void windowClosing(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowOpened(WindowEvent e) {}

    // override to reposition frame (for appearances sake only)
    public synchronized void setVisible(boolean vis) {
        if(vis == true) {
            setLocation(50, 50);
        }
            super.setVisible(vis);
    }

    public static void main( String args[]) {

        // create an object of its own class
        RoomBookingClientApplication gui =
            new RoomBookingClientApplication();

        gui.setVisible(true);

        // create a RoomBookingClient object -
        // using the application constructor
        client = new RoomBookingClient(args);

        // initialise the GUI
        client.init_GUI( gui );

        // view existing bookings
        // client.view();
    }
}

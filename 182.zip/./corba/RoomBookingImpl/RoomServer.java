package corba.RoomBookingImpl;

import java.io.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.NamingContextPackage.*;
import corba.RoomBooking.*;
import org.omg.CosNaming.*;

public class RoomServer {

    public static void main(String[] args) {

        String context_name, str_name;

	/* JN
        if( args.length != 1 ) {
            System.out.println("Usage: vbj com.wiley.compbooks.vogel.chpater9.RoomBookingImpl.RoomServer room_name");
            System.exit( 1 );
	}
	*/

        context_name = new String("/BuildingApplications/Rooms/");

        try {
	    //init
	    ORB orb = ORB.init( args, null );
	    // BOA boa = orb.BOA_init();

	    // create the Room object
	    RoomImpl room = new RoomImpl( args[0] );
	    orb.connect(room);

	    // export the object reference
	    // boa.obj_is_ready(room);

	    /*
            // register with naming service
            EasyNaming easy_naming = new EasyNaming( orb );

            str_name = context_name + args[0];

            easy_naming.bind_from_string( str_name, room );
	    */
            str_name = context_name + args[0];
	    org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
	    NamingContext ncRef = NamingContextHelper.narrow(objRef);

	    NameComponent nc1 = new NameComponent(context_name, " ");
	    NameComponent context_path[] = {nc1};

	    // if we don't have a context, create one
	    /* don't know what this does
	    try {
		ncRef.resolve(context_path);
	    } catch(NotFound e) {
		NamingContext ctxRef = ncRef.bind_new_context(context_path);
	    }
	    */

	    NameComponent nc2 = new NameComponent(args[0], " ");
	    NameComponent path[] = {nc1, nc2};
	    ncRef.rebind(path, room);


	    // wait for requests
	    // boa.impl_is_ready();
	    try {
		Thread.sleep(1000000);
	    } catch(Exception e) {
	    }
        }
	/*
	catch( AlreadyBound already_bound ) {
	    System.err.println("Room " + context_name + args[0] +
                " already bound.");
	    System.err.println("exiting ...");
        }
	*/
	catch(UserException ue) {
	    System.err.println(ue);
	    ue.printStackTrace();
	    System.err.println("Room " + context_name + args[0] +
                " already bound.");
        }
	catch(SystemException se) {
	    System.err.println(se);
        }
    }
}

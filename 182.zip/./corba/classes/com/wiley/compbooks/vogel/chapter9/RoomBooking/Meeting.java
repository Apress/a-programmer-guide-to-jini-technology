package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface Meeting extends org.omg.CORBA.Object {
  public java.lang.String purpose();
  public java.lang.String participants();
  public void destroy();
}

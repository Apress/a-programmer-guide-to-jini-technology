package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface MeetingFactory extends org.omg.CORBA.Object {
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting CreateMeeting(
    java.lang.String purpose,
    java.lang.String participants
  );
}

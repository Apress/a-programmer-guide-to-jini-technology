package com.wiley.compbooks.vogel.chapter9.RoomBooking;
final public class MeetingFactoryHolder implements org.omg.CORBA.portable.Streamable {
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory value;
  public MeetingFactoryHolder() {
  }
  public MeetingFactoryHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = MeetingFactoryHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    MeetingFactoryHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return MeetingFactoryHelper.type();
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
final public class MeetingHolder implements org.omg.CORBA.portable.Streamable {
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting value;
  public MeetingHolder() {
  }
  public MeetingHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = MeetingHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    MeetingHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return MeetingHelper.type();
  }
}

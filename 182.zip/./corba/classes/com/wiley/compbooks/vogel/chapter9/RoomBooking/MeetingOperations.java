package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface MeetingOperations {
  public void destroy();
  public java.lang.String purpose();
  public java.lang.String participants();
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface Room extends org.omg.CORBA.Object {
  final public static short MaxSlots = (short) 8;
  public java.lang.String name();
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View();
  public void Book(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot,
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken;
  public void Cancel(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot;
}

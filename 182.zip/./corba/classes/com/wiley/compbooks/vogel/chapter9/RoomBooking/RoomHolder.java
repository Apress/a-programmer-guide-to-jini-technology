package com.wiley.compbooks.vogel.chapter9.RoomBooking;
final public class RoomHolder implements org.omg.CORBA.portable.Streamable {
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Room value;
  public RoomHolder() {
  }
  public RoomHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.Room value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = RoomHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    RoomHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return RoomHelper.type();
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface RoomOperations {
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View();
  public void Book(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot,
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken;
  public void Cancel(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot;
  public java.lang.String name();
}

  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  public interface MaxSlots {
    final public static short value = (short) 8;
  }

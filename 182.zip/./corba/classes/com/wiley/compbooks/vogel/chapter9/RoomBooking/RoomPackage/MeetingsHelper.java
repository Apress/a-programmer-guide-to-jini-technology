  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  abstract public class MeetingsHelper {
    private static org.omg.CORBA.ORB _orb() {
      return org.omg.CORBA.ORB.init();
    }
    public static com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] read(org.omg.CORBA.portable.InputStream _input) {
      com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] result;
      {
        result = new com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[8];
        for(int _i4 = 0; _i4 < 8; _i4++) {
          result[_i4] = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.read(_input);
        }
      }
      return result;
    }
    public static void write(org.omg.CORBA.portable.OutputStream _output, com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] value) {
      if(value.length != 8) {
        throw new org.omg.CORBA.BAD_PARAM("Invalid array length");
      }
      for(int _i3 = 0; _i3 < value.length; _i3++) {
        com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.write(_output, value[_i3]);
      }
    }
    public static void insert(org.omg.CORBA.Any any, com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] value) {
      org.omg.CORBA.portable.OutputStream output = any.create_output_stream();
      write(output, value);
      any.read_value(output.create_input_stream(), type());
    }
    public static com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] extract(org.omg.CORBA.Any any) {
      if(!any.type().equal(type())) {
        throw new org.omg.CORBA.BAD_TYPECODE();
      }
      return read(any.create_input_stream());
    }
    private static org.omg.CORBA.TypeCode _type;
    public static org.omg.CORBA.TypeCode type() {
      if(_type == null) {
        org.omg.CORBA.TypeCode original_type = _orb().create_array_tc(8, com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type());
        _type = _orb().create_alias_tc(id(), "Meetings", original_type);
      }
      return _type;
    }
    public static java.lang.String id() {
      return "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room/Meetings:1.0";
    }
  }

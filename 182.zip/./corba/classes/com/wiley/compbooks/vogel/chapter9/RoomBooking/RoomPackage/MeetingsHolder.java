  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class MeetingsHolder implements org.omg.CORBA.portable.Streamable {
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] value;
    public MeetingsHolder() {
    }
    public MeetingsHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] value) {
      this.value = value;
    }
    public void _read(org.omg.CORBA.portable.InputStream input) {
      value = MeetingsHelper.read(input);
    }
    public void _write(org.omg.CORBA.portable.OutputStream output) {
      MeetingsHelper.write(output, value);
    }
    public org.omg.CORBA.TypeCode _type() {
      return MeetingsHelper.type();
    }
  }

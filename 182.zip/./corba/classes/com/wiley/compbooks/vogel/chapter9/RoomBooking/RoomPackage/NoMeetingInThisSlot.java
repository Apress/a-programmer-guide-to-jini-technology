  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class NoMeetingInThisSlot extends org.omg.CORBA.UserException {
    public NoMeetingInThisSlot() {
    }
    public java.lang.String toString() {
      org.omg.CORBA.Any any = org.omg.CORBA.ORB.init().create_any();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.insert(any, this);
      return any.toString();
    }
  }

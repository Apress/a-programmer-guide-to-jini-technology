  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class NoMeetingInThisSlotHolder implements org.omg.CORBA.portable.Streamable {
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot value;
    public NoMeetingInThisSlotHolder() {
    }
    public NoMeetingInThisSlotHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot value) {
      this.value = value;
    }
    public void _read(org.omg.CORBA.portable.InputStream input) {
      value = NoMeetingInThisSlotHelper.read(input);
    }
    public void _write(org.omg.CORBA.portable.OutputStream output) {
      NoMeetingInThisSlotHelper.write(output, value);
    }
    public org.omg.CORBA.TypeCode _type() {
      return NoMeetingInThisSlotHelper.type();
    }
  }

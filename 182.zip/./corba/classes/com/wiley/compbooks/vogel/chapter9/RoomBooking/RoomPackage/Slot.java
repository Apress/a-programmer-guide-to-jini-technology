  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class Slot {
    final public static int _am9 = 0;
    final public static int _am10 = 1;
    final public static int _am11 = 2;
    final public static int _pm12 = 3;
    final public static int _pm1 = 4;
    final public static int _pm2 = 5;
    final public static int _pm3 = 6;
    final public static int _pm4 = 7;
    final public static Slot am9 = new Slot(_am9);
    final public static Slot am10 = new Slot(_am10);
    final public static Slot am11 = new Slot(_am11);
    final public static Slot pm12 = new Slot(_pm12);
    final public static Slot pm1 = new Slot(_pm1);
    final public static Slot pm2 = new Slot(_pm2);
    final public static Slot pm3 = new Slot(_pm3);
    final public static Slot pm4 = new Slot(_pm4);
    private int __value;
    private Slot(int value) {
      this.__value = value;
    }
    public int value() {
      return __value;
    }
    public static Slot from_int(int $value) {
      switch($value) {
      case _am9:
        return am9;
      case _am10:
        return am10;
      case _am11:
        return am11;
      case _pm12:
        return pm12;
      case _pm1:
        return pm1;
      case _pm2:
        return pm2;
      case _pm3:
        return pm3;
      case _pm4:
        return pm4;
      default:
        throw new org.omg.CORBA.BAD_PARAM("Enum out of range: [0.." + (8 - 1) + "]: " + $value);
      }
    }
    public java.lang.String toString() {
      org.omg.CORBA.Any any = org.omg.CORBA.ORB.init().create_any();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.insert(any, this);
      return any.toString();
    }
  }

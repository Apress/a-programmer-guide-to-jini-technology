  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class SlotAlreadyTaken extends org.omg.CORBA.UserException {
    public SlotAlreadyTaken() {
    }
    public java.lang.String toString() {
      org.omg.CORBA.Any any = org.omg.CORBA.ORB.init().create_any();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.insert(any, this);
      return any.toString();
    }
  }

  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class SlotAlreadyTakenHolder implements org.omg.CORBA.portable.Streamable {
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken value;
    public SlotAlreadyTakenHolder() {
    }
    public SlotAlreadyTakenHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken value) {
      this.value = value;
    }
    public void _read(org.omg.CORBA.portable.InputStream input) {
      value = SlotAlreadyTakenHelper.read(input);
    }
    public void _write(org.omg.CORBA.portable.OutputStream output) {
      SlotAlreadyTakenHelper.write(output, value);
    }
    public org.omg.CORBA.TypeCode _type() {
      return SlotAlreadyTakenHelper.type();
    }
  }

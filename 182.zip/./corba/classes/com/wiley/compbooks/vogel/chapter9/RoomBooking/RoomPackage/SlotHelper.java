  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  abstract public class SlotHelper {
    private static org.omg.CORBA.ORB _orb() {
      return org.omg.CORBA.ORB.init();
    }
    public static com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot read(org.omg.CORBA.portable.InputStream _input) {
      return Slot.from_int(_input.read_long());
    }
    public static void write(org.omg.CORBA.portable.OutputStream _output, com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot value) {
      _output.write_long(value.value());
    }
    public static void insert(org.omg.CORBA.Any any, com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot value) {
      org.omg.CORBA.portable.OutputStream output = any.create_output_stream();
      write(output, value);
      any.read_value(output.create_input_stream(), type());
    }
    public static com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot extract(org.omg.CORBA.Any any) {
      if(!any.type().equal(type())) {
        throw new org.omg.CORBA.BAD_TYPECODE();
      }
      return read(any.create_input_stream());
    }
    private static org.omg.CORBA.TypeCode _type;
    public static org.omg.CORBA.TypeCode type() {
      if(_type == null) {
        String[] members = new String[8];
        members[0] = "am9";
        members[1] = "am10";
        members[2] = "am11";
        members[3] = "pm12";
        members[4] = "pm1";
        members[5] = "pm2";
        members[6] = "pm3";
        members[7] = "pm4";
        _type = _orb().create_enum_tc(id(), "Slot", members);
      }
      return _type;
    }
    public static java.lang.String id() {
      return "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room/Slot:1.0";
    }
  }

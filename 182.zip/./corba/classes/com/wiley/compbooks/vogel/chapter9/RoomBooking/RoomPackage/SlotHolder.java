  package com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage;
  final public class SlotHolder implements org.omg.CORBA.portable.Streamable {
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot value;
    public SlotHolder() {
    }
    public SlotHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot value) {
      this.value = value;
    }
    public void _read(org.omg.CORBA.portable.InputStream input) {
      value = SlotHelper.read(input);
    }
    public void _write(org.omg.CORBA.portable.OutputStream output) {
      SlotHelper.write(output, value);
    }
    public org.omg.CORBA.TypeCode _type() {
      return SlotHelper.type();
    }
  }

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
abstract public class _MeetingFactoryImplBase extends org.omg.CORBA.DynamicImplementation implements com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory {
  private java.lang.String _name;
  public String _object_name() {
    return _name;
  }
  protected _MeetingFactoryImplBase(java.lang.String name) {
    _name = name;
  }
  protected _MeetingFactoryImplBase() {
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingFactory:1.0"
  };
  private static java.util.Dictionary _methods = new java.util.Hashtable();
  static {
    _methods.put("CreateMeeting", new java.lang.Integer(0));
  }
  public void invoke(org.omg.CORBA.ServerRequest _request) {
    com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory _self = this;
    java.lang.Object _method = _methods.get(_request.op_name());
    if(_method == null) {
      throw new org.omg.CORBA.BAD_OPERATION(_request.op_name());
    }
    int _method_id = ((java.lang.Integer) _method).intValue();
    switch(_method_id) {
    case 0: {
      org.omg.CORBA.NVList _params = _orb().create_list(0);
      org.omg.CORBA.Any $purpose = _orb().create_any();
      $purpose.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
      _params.add_value("purpose", $purpose, org.omg.CORBA.ARG_IN.value);
      org.omg.CORBA.Any $participants = _orb().create_any();
      $participants.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
      _params.add_value("participants", $participants, org.omg.CORBA.ARG_IN.value);
      _request.params(_params);
      java.lang.String purpose;
      purpose = $purpose.extract_string();
      java.lang.String participants;
      participants = $participants.extract_string();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting _result = _self.CreateMeeting(purpose,participants);
      org.omg.CORBA.Any _resultAny = _orb().create_any();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.insert(_resultAny, _result);
      _request.result(_resultAny);
      return;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}

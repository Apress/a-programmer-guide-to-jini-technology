package com.wiley.compbooks.vogel.chapter9.RoomBooking;
abstract public class _MeetingImplBase extends org.omg.CORBA.DynamicImplementation implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting {
  private java.lang.String _name;
  public String _object_name() {
    return _name;
  }
  protected _MeetingImplBase(java.lang.String name) {
    _name = name;
  }
  protected _MeetingImplBase() {
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Meeting:1.0"
  };
  private static java.util.Dictionary _methods = new java.util.Hashtable();
  static {
    _methods.put("destroy", new java.lang.Integer(0));
    _methods.put("_get_purpose", new java.lang.Integer(1));
    _methods.put("_get_participants", new java.lang.Integer(2));
  }
  public void invoke(org.omg.CORBA.ServerRequest _request) {
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting _self = this;
    java.lang.Object _method = _methods.get(_request.op_name());
    if(_method == null) {
      throw new org.omg.CORBA.BAD_OPERATION(_request.op_name());
    }
    int _method_id = ((java.lang.Integer) _method).intValue();
    switch(_method_id) {
    case 0: {
      _self.destroy();
      return;
    }
    case 1: {
      java.lang.String _result = _self.purpose();
      org.omg.CORBA.Any _resultAny = _orb().create_any();
      _resultAny.insert_string(_result);
      _request.result(_resultAny);
      return;
    }
    case 2: {
      java.lang.String _result = _self.participants();
      org.omg.CORBA.Any _resultAny = _orb().create_any();
      _resultAny.insert_string(_result);
      _request.result(_resultAny);
      return;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}

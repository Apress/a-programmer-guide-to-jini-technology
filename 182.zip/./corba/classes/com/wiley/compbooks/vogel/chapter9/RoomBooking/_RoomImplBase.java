package com.wiley.compbooks.vogel.chapter9.RoomBooking;
abstract public class _RoomImplBase extends org.omg.CORBA.DynamicImplementation implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Room {
  private java.lang.String _name;
  public String _object_name() {
    return _name;
  }
  protected _RoomImplBase(java.lang.String name) {
    _name = name;
  }
  protected _RoomImplBase() {
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room:1.0"
  };
  private static java.util.Dictionary _methods = new java.util.Hashtable();
  static {
    _methods.put("View", new java.lang.Integer(0));
    _methods.put("Book", new java.lang.Integer(1));
    _methods.put("Cancel", new java.lang.Integer(2));
    _methods.put("_get_name", new java.lang.Integer(3));
  }
  public void invoke(org.omg.CORBA.ServerRequest _request) {
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Room _self = this;
    java.lang.Object _method = _methods.get(_request.op_name());
    if(_method == null) {
      throw new org.omg.CORBA.BAD_OPERATION(_request.op_name());
    }
    int _method_id = ((java.lang.Integer) _method).intValue();
    switch(_method_id) {
    case 0: {
      com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] _result = _self.View();
      org.omg.CORBA.Any _resultAny = _orb().create_any();
      com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.MeetingsHelper.insert(_resultAny, _result);
      _request.result(_resultAny);
      return;
    }
    case 1: {
      try {
        org.omg.CORBA.NVList _params = _orb().create_list(0);
        org.omg.CORBA.Any $a_slot = _orb().create_any();
        $a_slot.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.type());
        _params.add_value("a_slot", $a_slot, org.omg.CORBA.ARG_IN.value);
        org.omg.CORBA.Any $a_meeting = _orb().create_any();
        $a_meeting.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type());
        _params.add_value("a_meeting", $a_meeting, org.omg.CORBA.ARG_IN.value);
        _request.params(_params);
        com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot;
        a_slot = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.extract($a_slot);
        com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting;
        a_meeting = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.extract($a_meeting);
        _self.Book(a_slot,a_meeting);
      }
      catch(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken _exception) {
        org.omg.CORBA.Any _exceptionAny = _orb().create_any();
        com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.insert(_exceptionAny, _exception);
        _request.except(_exceptionAny);
      }
      return;
    }
    case 2: {
      try {
        org.omg.CORBA.NVList _params = _orb().create_list(0);
        org.omg.CORBA.Any $a_slot = _orb().create_any();
        $a_slot.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.type());
        _params.add_value("a_slot", $a_slot, org.omg.CORBA.ARG_IN.value);
        _request.params(_params);
        com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot;
        a_slot = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.extract($a_slot);
        _self.Cancel(a_slot);
      }
      catch(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot _exception) {
        org.omg.CORBA.Any _exceptionAny = _orb().create_any();
        com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.insert(_exceptionAny, _exception);
        _request.except(_exceptionAny);
      }
      return;
    }
    case 3: {
      java.lang.String _result = _self.name();
      org.omg.CORBA.Any _resultAny = _orb().create_any();
      _resultAny.insert_string(_result);
      _request.result(_resultAny);
      return;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}

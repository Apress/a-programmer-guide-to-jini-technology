package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _portable_stub_Meeting extends org.omg.CORBA.portable.ObjectImpl implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting {
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Meeting:1.0"
  };
  public void destroy() {
    org.omg.CORBA.Request _request = this._request("destroy");
    _request.send_oneway();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
  }
  public java.lang.String purpose() {
    org.omg.CORBA.Request _request = this._request("_get_purpose");
    _request.set_return_type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
    java.lang.String _result;
    _result = _request.return_value().extract_string();
    return _result;
  }
  public java.lang.String participants() {
    org.omg.CORBA.Request _request = this._request("_get_participants");
    _request.set_return_type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
    java.lang.String _result;
    _result = _request.return_value().extract_string();
    return _result;
  }
}

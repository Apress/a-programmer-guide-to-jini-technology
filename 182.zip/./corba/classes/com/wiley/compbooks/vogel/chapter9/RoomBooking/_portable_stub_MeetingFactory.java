package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _portable_stub_MeetingFactory extends org.omg.CORBA.portable.ObjectImpl implements com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory {
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingFactory:1.0"
  };
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting CreateMeeting(
    java.lang.String purpose,
    java.lang.String participants
  ) {
    org.omg.CORBA.Request _request = this._request("CreateMeeting");
    _request.set_return_type(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type());
    org.omg.CORBA.Any $purpose = _request.add_in_arg();
    $purpose.insert_string(purpose);
    org.omg.CORBA.Any $participants = _request.add_in_arg();
    $participants.insert_string(participants);
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting _result;
    _result = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.extract(_request.return_value());
    return _result;
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _portable_stub_Room extends org.omg.CORBA.portable.ObjectImpl implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Room {
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room:1.0"
  };
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View() {
    org.omg.CORBA.Request _request = this._request("View");
    _request.set_return_type(_orb().create_array_tc(8, com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type()));
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] _result;
    _result = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.MeetingsHelper.extract(_request.return_value());
    return _result;
  }
  public void Book(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot,
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken {
    org.omg.CORBA.Request _request = this._request("Book");
    org.omg.CORBA.Any $a_slot = _request.add_in_arg();
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.insert($a_slot, a_slot);
    org.omg.CORBA.Any $a_meeting = _request.add_in_arg();
    com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.insert($a_meeting, a_meeting);
    _request.exceptions().add(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.type());
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      if(_exception instanceof org.omg.CORBA.UnknownUserException) {
        org.omg.CORBA.UnknownUserException _userException = 
          (org.omg.CORBA.UnknownUserException) _exception;
        if(_userException.except.type().equals(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.type())) {
          throw com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.extract(_userException.except);
        }
      }
      throw (org.omg.CORBA.SystemException) _exception;
    }
  }
  public void Cancel(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot {
    org.omg.CORBA.Request _request = this._request("Cancel");
    org.omg.CORBA.Any $a_slot = _request.add_in_arg();
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.insert($a_slot, a_slot);
    _request.exceptions().add(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.type());
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      if(_exception instanceof org.omg.CORBA.UnknownUserException) {
        org.omg.CORBA.UnknownUserException _userException = 
          (org.omg.CORBA.UnknownUserException) _exception;
        if(_userException.except.type().equals(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.type())) {
          throw com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.extract(_userException.except);
        }
      }
      throw (org.omg.CORBA.SystemException) _exception;
    }
  }
  public java.lang.String name() {
    org.omg.CORBA.Request _request = this._request("_get_name");
    _request.set_return_type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
    _request.invoke();
    java.lang.Exception _exception = _request.env().exception();
    if(_exception != null) {
      throw (org.omg.CORBA.SystemException) _exception;
    }
    java.lang.String _result;
    _result = _request.return_value().extract_string();
    return _result;
  }
}

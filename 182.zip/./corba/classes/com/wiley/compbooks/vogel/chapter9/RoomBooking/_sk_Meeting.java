package com.wiley.compbooks.vogel.chapter9.RoomBooking;
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _MeetingImplBase
abstract public class _sk_Meeting extends _MeetingImplBase {
  protected _sk_Meeting(java.lang.String name) {
    super(name);
  }
  protected _sk_Meeting() {
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _MeetingFactoryImplBase
abstract public class _sk_MeetingFactory extends _MeetingFactoryImplBase {
  protected _sk_MeetingFactory(java.lang.String name) {
    super(name);
  }
  protected _sk_MeetingFactory() {
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
// Warning: 
//   This class has been deprecated by the new IDL to Java Language mapping.
//   Please use the new implementation base class: _RoomImplBase
abstract public class _sk_Room extends _RoomImplBase {
  protected _sk_Room(java.lang.String name) {
    super(name);
  }
  protected _sk_Room() {
  }
}

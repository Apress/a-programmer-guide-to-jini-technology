package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _tie_Meeting extends com.wiley.compbooks.vogel.chapter9.RoomBooking._MeetingImplBase {
  private com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingOperations _delegate;
  public _tie_Meeting(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_Meeting(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingOperations delegate) {
    this._delegate = delegate;
  }
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingOperations _delegate() {
    return this._delegate;
  }
  public void destroy() {
    this._delegate.destroy(
    );
  }
  public java.lang.String purpose() {
    return this._delegate.purpose();
  }
  public java.lang.String participants() {
    return this._delegate.participants();
  }
}

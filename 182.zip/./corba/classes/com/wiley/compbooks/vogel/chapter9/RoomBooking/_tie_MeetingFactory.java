package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _tie_MeetingFactory extends com.wiley.compbooks.vogel.chapter9.RoomBooking._MeetingFactoryImplBase {
  private com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactoryOperations _delegate;
  public _tie_MeetingFactory(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactoryOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_MeetingFactory(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactoryOperations delegate) {
    this._delegate = delegate;
  }
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactoryOperations _delegate() {
    return this._delegate;
  }
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting CreateMeeting(
    java.lang.String purpose,
    java.lang.String participants
  ) {
    return this._delegate.CreateMeeting(
      purpose,
      participants
    );
  }
}

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _tie_Room extends com.wiley.compbooks.vogel.chapter9.RoomBooking._RoomImplBase {
  private com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomOperations _delegate;
  public _tie_Room(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_Room(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomOperations delegate) {
    this._delegate = delegate;
  }
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomOperations _delegate() {
    return this._delegate;
  }
  public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View() {
    return this._delegate.View(
    );
  }
  public void Book(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot,
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken {
    this._delegate.Book(
      a_slot,
      a_meeting
    );
  }
  public void Cancel(
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot
  ) throws
    com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot {
    this._delegate.Cancel(
      a_slot
    );
  }
  public java.lang.String name() {
    return this._delegate.name();
  }
}

//	FileClassifier.java
//	-------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:06 GMT+10:00 1999
//

package common ;


public interface FileClassifier extends org.omg.CORBA.Object
{
    public org.omg.CORBA.Any getMIMEType( java.lang.String fileName ) ;
}


//	FileClassifierClient.java
//	-------------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:07 GMT+10:00 1999
//

package common ;


import org.omg.CORBA.portable.ObjectImpl ;

public class FileClassifierClient extends org.omg.CORBA.portable.ObjectImpl implements common.FileClassifier
{
    private static java.lang.String[] __ids = 
    {
        "IDL:common/FileClassifier:1.0"
    } ;

    private static org.omg.CORBA.ORB _er_orb = org.omg.CORBA.ORB.init() ;

    public java.lang.String[] _ids() { return __ids ; }

    public org.omg.CORBA.Any getMIMEType( java.lang.String fileName )
    {
        org.omg.CORBA.Any _er_rtn ; 

        try
        {
            org.omg.CORBA.portable.OutputStream _er_output = _request( "getMIMEType", true ) ;
            _er_output.write_string( fileName ) ;
            org.omg.CORBA.portable.InputStream _er_input = _invoke( _er_output, null ) ;
            _er_rtn = _er_input.read_any() ;

        }
        catch ( org.omg.CORBA.SystemException sysE )
        {
            throw sysE ;
        }

        return _er_rtn ;
    }
}


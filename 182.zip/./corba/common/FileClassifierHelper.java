//	FileClassifierHelper.java
//	-------------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:07 GMT+10:00 1999
//

package common ;


public class FileClassifierHelper
{
    private static org.omg.CORBA.ORB _er_orb() { return org.omg.CORBA.ORB.init() ; }
    public static void insert( org.omg.CORBA.Any any, common.FileClassifier value )
    {
        org.omg.CORBA.portable.OutputStream out = any.create_output_stream() ;
        write( out, value ) ;
        any.read_value( out.create_input_stream(), type() ) ;
    }

    public static common.FileClassifier extract( org.omg.CORBA.Any any )
    {
        if ( ! any.type().equal( type() ) )
            throw new org.omg.CORBA.BAD_TYPECODE() ;

        return read( any.create_input_stream() ) ;
    }

    public static String id() { return "IDL:common/FileClassifier:1.0" ; }

    private static org.omg.CORBA.TypeCode _er_type = null ;

    public static org.omg.CORBA.TypeCode type()
    {
        if ( _er_type == null )
        {
            _er_type = _er_orb().create_interface_tc( id(), "FileClassifier" ) ;
        }
        return _er_type ; 
    }

    public static common.FileClassifier read( org.omg.CORBA.portable.InputStream _er_input )
    {
        return common.FileClassifierHelper.narrow( _er_input.read_Object() ) ;
    }

    public static void write( org.omg.CORBA.portable.OutputStream _er_output, common.FileClassifier v )
    {
        _er_output.write_Object( v ) ;
    }

    public static common.FileClassifier narrow( org.omg.CORBA.Object obj )
    {
        if ( obj == null )
            return null ;

        if ( obj instanceof common.FileClassifier )
            return ( common.FileClassifier )obj ;

        if ( obj._is_a( id() ) )
        {
            org.omg.CORBA.portable.ObjectImpl impl = ( org.omg.CORBA.portable.ObjectImpl )obj ;
            StubForFileClassifier stub = new StubForFileClassifier() ;
            stub._set_delegate( impl._get_delegate() ) ;
            return stub ;
        }
        throw new org.omg.CORBA.BAD_PARAM( "Can't narrow " ) ;
    }

}

//	FileClassifierHolder.java
//	-------------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:07 GMT+10:00 1999
//

package common ;


public class FileClassifierHolder implements org.omg.CORBA.portable.Streamable
{
    public common.FileClassifier value ;
    public FileClassifierHolder() {}
    public FileClassifierHolder( common.FileClassifier initial ) { value = initial ; }

    public void _read( org.omg.CORBA.portable.InputStream _er_input )
    {
        value = common.FileClassifierHelper.read( _er_input ) ;
    }

    public void _write( org.omg.CORBA.portable.OutputStream _er_output )
    {
        common.FileClassifierHelper.write( _er_output, value ) ;
    }

    public org.omg.CORBA.TypeCode _type() { return null ; }
}

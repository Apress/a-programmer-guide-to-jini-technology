
/**
 * JavaMeeting.java
 *
 *
 * Created: Tue Aug 24 20:00:31 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */
package corba.common;

import java.io.Serializable;
import org.omg.CORBA.*;
import corba.RoomBooking.*;
import java.rmi.RemoteException;

public interface JavaMeeting extends Serializable {
    String getPurpose();
    String getParticipants();
    Meeting getMeeting(ORB orb);
} // JavaMeeting

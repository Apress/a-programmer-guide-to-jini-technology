
/**
 * JavaRoom.java
 *
 *
 * Created: Tue Aug 24 20:00:31 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */
package corba.common;

import corba.RoomBooking.*;
import java.io.Serializable;
import org.omg.CORBA.*;
import java.rmi.RemoteException;

public interface JavaRoom extends Serializable {
    String getName();
    Room getRoom(ORB orb);
} // JavaRoom

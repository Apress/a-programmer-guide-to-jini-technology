
/**
 * RoomBookingBridge.java
 *
 *
 * Created: Sun Aug 29 11:11:46 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package corba.common;

import java.rmi.RemoteException;
import corba.RoomBooking.*;
import org.omg.CORBA.*;

public interface RoomBookingBridge extends java.io.Serializable {
    
    public void cancel(int selected_room, int selected_slot)
	throws RemoteException, NoMeetingInThisSlot;
    public void book(String purpose, String participants,
		     int selected_room, int selected_slot)
	throws RemoteException, SlotAlreadyTaken;
    public void update()
	throws RemoteException, UserException;
    public JavaRoom[] getRooms()
	throws RemoteException;
    public JavaMeeting[] getMeetings(int room_index)
	throws RemoteException;
} // RoomBookingBridge

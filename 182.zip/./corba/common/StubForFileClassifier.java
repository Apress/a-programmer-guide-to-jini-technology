//	StubForFileClassifier.java
//	--------------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:07 GMT+10:00 1999
//

package common ;


public class StubForFileClassifier extends
    org.omg.CORBA.portable.ObjectImpl implements FileClassifier
{
    private static java.lang.String[] __ids = 
    {
        "IDL:common/FileClassifier:1.0"
    } ;

    private static org.omg.CORBA.ORB _er_orb = org.omg.CORBA.ORB.init() ;

    public java.lang.String[] _ids() { return __ids ; }

    public org.omg.CORBA.Any getMIMEType( java.lang.String fileName )
    {
        org.omg.CORBA.Request _er_request = _request( "getMIMEType" ) ;
        org.omg.CORBA.Any _er_fileName = _er_request.add_in_arg() ;
        _er_fileName.insert_string( fileName ) ;
        _er_request.set_return_type( _er_orb.get_primitive_tc( org.omg.CORBA.TCKind.tk_any ) ) ;
        _er_request.invoke() ;
        java.lang.Exception _er_exception = _er_request.env().exception() ;
        if ( _er_exception != null )
        {
            throw ( org.omg.CORBA.SystemException )_er_exception ;
        }
        org.omg.CORBA.Any _er_rtn = _er_request.return_value().extract_any() ;
        return _er_rtn ;
    }

}


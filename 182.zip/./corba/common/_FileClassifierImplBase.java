//	_FileClassifierImplBase.java
//	----------------------------
//
//	THIS IS NOT SOURCE CODE - DO NOT EDIT IT
//
//	It was created by Mitch Britton's IDL compiler
//	On Thu Aug 19 22:18:07 GMT+10:00 1999
//

package common ;


abstract public class _FileClassifierImplBase extends
    org.omg.CORBA.DynamicImplementation implements FileClassifier
{
    private static java.lang.String[] __ids = 
    {
        "IDL:common/FileClassifier:1.0"
    } ;

    private static org.omg.CORBA.ORB _er_orb = org.omg.CORBA.ORB.init() ;

    public java.lang.String[] _ids() { return __ids ; }

    public FileClassifier _this() { return this ; }

    public _FileClassifierImplBase() {}

    public void invoke( org.omg.CORBA.ServerRequest _er_request )
    {
        java.lang.Integer _er_operation = ( java.lang.Integer )_er_operations.get( _er_request.op_name() ) ;

        if ( _er_operation == null )
            throw new org.omg.CORBA.BAD_OPERATION( _er_request.op_name() ) ;

        switch( _er_operation.intValue() )
        {
            case 0 :
            {
                org.omg.CORBA.NVList _er_params = _er_orb.create_list(0) ;
                org.omg.CORBA.Any _er_fileName = _er_orb.create_any() ;
                _er_fileName.type( _er_orb.create_string_tc( 0 ) ) ;
                _er_params.add_value( "fileName", _er_fileName, org.omg.CORBA.ARG_IN.value ) ;
                _er_request.params( _er_params ) ;
                java.lang.String fileName ;
                fileName = _er_fileName.extract_string() ;
                org.omg.CORBA.Any _er_rtn = getMIMEType( fileName ) ;
                org.omg.CORBA.Any _er__er_rtn = _er_orb.create_any() ;
                _er_request.result( _er__er_rtn ) ;
                _er__er_rtn.insert_any( _er_rtn ) ;
            }
            break ;

            default: throw new org.omg.CORBA.MARSHAL() ;
        }
    }

    private static java.util.Hashtable _er_operations = new java.util.Hashtable() ; 

    static
    {
        _er_operations.put( "getMIMEType", new java.lang.Integer( 0 ) ) ;
    }

}


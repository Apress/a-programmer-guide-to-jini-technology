/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/Meeting.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface Meeting
    extends org.omg.CORBA.Object {
    String purpose();
    String participants();
    void destroy()
;
}

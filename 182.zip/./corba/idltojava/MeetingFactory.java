/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingFactory.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface MeetingFactory
    extends org.omg.CORBA.Object {
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting CreateMeeting(String purpose, String participants)
;
}

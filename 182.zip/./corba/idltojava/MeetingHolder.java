/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingHolder.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public final class MeetingHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting value;
    //	constructors 
    public MeetingHolder() {
	this(null);
    }
    public MeetingHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type();
    }
}

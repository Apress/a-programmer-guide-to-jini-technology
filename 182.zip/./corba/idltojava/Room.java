/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/Room.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public interface Room
    extends org.omg.CORBA.Object {
    public static final short MaxSlots = (short) (8L);
    String name();
    com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View()
;
    void Book(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot, com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting)
        throws com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken;
    void Cancel(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot)
        throws com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot;
}

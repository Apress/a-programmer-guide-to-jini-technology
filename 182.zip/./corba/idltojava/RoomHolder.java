/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/RoomHolder.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public final class RoomHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.Room value;
    //	constructors 
    public RoomHolder() {
	this(null);
    }
    public RoomHolder(com.wiley.compbooks.vogel.chapter9.RoomBooking.Room __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomHelper.type();
    }
}

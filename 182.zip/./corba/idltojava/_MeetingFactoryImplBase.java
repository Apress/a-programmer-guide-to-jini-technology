/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/_MeetingFactoryImplBase.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public abstract class _MeetingFactoryImplBase extends org.omg.CORBA.DynamicImplementation implements com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory {
    // Constructor
    public _MeetingFactoryImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("CreateMeeting", new java.lang.Integer(0));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory.CreateMeeting
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _purpose = _orb().create_any();
              _purpose.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("purpose", _purpose, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _participants = _orb().create_any();
              _participants.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("participants", _participants, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              String purpose;
              purpose = _purpose.extract_string();
              String participants;
              participants = _participants.extract_string();
              com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting ___result;
                            ___result = this.CreateMeeting(purpose, participants);
              org.omg.CORBA.Any __result = _orb().create_any();
              com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}

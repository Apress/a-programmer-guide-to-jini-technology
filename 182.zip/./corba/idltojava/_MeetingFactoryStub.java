/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/_MeetingFactoryStub.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _MeetingFactoryStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingFactory {

    public _MeetingFactoryStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/MeetingFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::com::wiley::compbooks::vogel::chapter9::RoomBooking::MeetingFactory::CreateMeeting
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting CreateMeeting(String purpose, String participants)
 {
           org.omg.CORBA.Request r = _request("CreateMeeting");
           r.set_return_type(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type());
           org.omg.CORBA.Any _purpose = r.add_in_arg();
           _purpose.insert_string(purpose);
           org.omg.CORBA.Any _participants = r.add_in_arg();
           _participants.insert_string(participants);
           r.invoke();
           com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting __result;
           __result = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.extract(r.return_value());
           return __result;
   }

};

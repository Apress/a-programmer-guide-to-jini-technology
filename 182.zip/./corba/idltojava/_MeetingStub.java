/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/_MeetingStub.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _MeetingStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting {

    public _MeetingStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Meeting:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	Implementation of attribute ::purpose
    public String purpose() {
           org.omg.CORBA.Request r = _request("_get_purpose");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	Implementation of attribute ::participants
    public String participants() {
           org.omg.CORBA.Request r = _request("_get_participants");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::com::wiley::compbooks::vogel::chapter9::RoomBooking::Meeting::destroy
    public void destroy()
 {
           org.omg.CORBA.Request r = _request("destroy");
           r.send_oneway();
   }

};

/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/_RoomImplBase.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public abstract class _RoomImplBase extends org.omg.CORBA.DynamicImplementation implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Room {
    // Constructor
    public _RoomImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("_get_name", new java.lang.Integer(0));
      _methods.put("View", new java.lang.Integer(1));
      _methods.put("Book", new java.lang.Integer(2));
      _methods.put("Cancel", new java.lang.Integer(3));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // com.wiley.compbooks.vogel.chapter9.RoomBooking.Room.name
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              String ___result = this.name();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_string(___result);
              r.result(__result);
              }
              break;
           case 1: // com.wiley.compbooks.vogel.chapter9.RoomBooking.Room.View
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] ___result;
                            ___result = this.View();
              org.omg.CORBA.Any __result = _orb().create_any();
              com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.MeetingsHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 2: // com.wiley.compbooks.vogel.chapter9.RoomBooking.Room.Book
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _a_slot = _orb().create_any();
              _a_slot.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.type());
              _list.add_value("a_slot", _a_slot, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _a_meeting = _orb().create_any();
              _a_meeting.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.type());
              _list.add_value("a_meeting", _a_meeting, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot;
              a_slot = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.extract(_a_slot);
              com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting;
              a_meeting = com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.extract(_a_meeting);
              try {
                            this.Book(a_slot, a_meeting);
              }
              catch (com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
           case 3: // com.wiley.compbooks.vogel.chapter9.RoomBooking.Room.Cancel
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _a_slot = _orb().create_any();
              _a_slot.type(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.type());
              _list.add_value("a_slot", _a_slot, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot;
              a_slot = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.extract(_a_slot);
              try {
                            this.Cancel(a_slot);
              }
              catch (com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}

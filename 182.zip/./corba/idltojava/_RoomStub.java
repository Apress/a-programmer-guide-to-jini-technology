/*
 * File: ./com/wiley/compbooks/vogel/chapter9/RoomBooking/_RoomStub.java
 * From: RoomBooking.idl
 * Date: Sun Nov 16 15:56:14 1997
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package com.wiley.compbooks.vogel.chapter9.RoomBooking;
public class _RoomStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements com.wiley.compbooks.vogel.chapter9.RoomBooking.Room {

    public _RoomStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:com/wiley/compbooks/vogel/chapter9/RoomBooking/Room:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	Implementation of attribute ::name
    public String name() {
           org.omg.CORBA.Request r = _request("_get_name");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::com::wiley::compbooks::vogel::chapter9::RoomBooking::Room::View
    public com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] View()
 {
           org.omg.CORBA.Request r = _request("View");
           r.set_return_type(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.MeetingsHelper.type());
           r.invoke();
           com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting[] __result;
           __result = com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.MeetingsHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::com::wiley::compbooks::vogel::chapter9::RoomBooking::Room::Book
    public void Book(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot, com.wiley.compbooks.vogel.chapter9.RoomBooking.Meeting a_meeting)
        throws com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTaken {
           org.omg.CORBA.Request r = _request("Book");
           org.omg.CORBA.Any _a_slot = r.add_in_arg();
           com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.insert(_a_slot, a_slot);
           org.omg.CORBA.Any _a_meeting = r.add_in_arg();
           com.wiley.compbooks.vogel.chapter9.RoomBooking.MeetingHelper.insert(_a_meeting, a_meeting);
           r.exceptions().add(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.type())) {
                   throw com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotAlreadyTakenHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::com::wiley::compbooks::vogel::chapter9::RoomBooking::Room::Cancel
    public void Cancel(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.Slot a_slot)
        throws com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlot {
           org.omg.CORBA.Request r = _request("Cancel");
           org.omg.CORBA.Any _a_slot = r.add_in_arg();
           com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.SlotHelper.insert(_a_slot, a_slot);
           r.exceptions().add(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.type())) {
                   throw com.wiley.compbooks.vogel.chapter9.RoomBooking.RoomPackage.NoMeetingInThisSlotHelper.extract(__userEx.except);
               }
           }
   }

};

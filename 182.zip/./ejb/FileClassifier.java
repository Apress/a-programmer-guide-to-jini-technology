package ejb;

/**
 * FileClassifier.java
 *
 *
 * Created: Wed May 10 09:26:38 2000
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import java.rmi.Remote;
import javax.ejb.*;
import common.MIMEType;

public interface FileClassifier extends EJBObject, Remote {

    MIMEType getMIMEType(String fileName)
        throws java.rmi.RemoteException;
} // FileClassifier

package ejb;

/**
 * FileClassifierBean.java
 *
 *
 * Created: Wed May 10 09:50:19 2000
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import javax.ejb.*;
import common.MIMEType;

public class FileClassifierBean implements SessionBean {
    
    public void ejbActivate() { 
	//empty 
    }
    
    public void ejbPassivate() { 
	//empty 
    }

    public void ejbRemove() {
	// empty
    }

    public void setSessionContext(SessionContext ctx) {
	// empty
    }

    public MIMEType getMIMEType(String fileName) {
        if (fileName.endsWith(".gif")) {
            return new MIMEType("image", "gif");
        } else if (fileName.endsWith(".jpeg")) {
            return new MIMEType("image", "jpeg");
        } else if (fileName.endsWith(".mpg")) {
            return new MIMEType("video", "mpeg");
        } else
            // fill in lots of other types,
            // but eventually give up and
            return null;
    }                                   
} // FileClassifierBean

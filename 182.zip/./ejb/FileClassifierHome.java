package ejb;

/**
 * FileClassifierHome.java
 *
 *
 * Created: Wed May 10 09:38:04 2000
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import javax.ejb.*;
import java.rmi.RemoteException;

public interface FileClassifierHome extends EJBHome {
    
    public FileClassifier create() throws CreateException, RemoteException;
    
} // FileClassifierHome


/**
 * RemoteExtendedFileClassifier.java
 *
 *
 * Created: Tue Oct 26 21:14:19 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package extended;

import java.rmi.Remote;

interface RemoteExtendedFileClassifier extends common.ExtendedFileClassifier, Remote {

} // RemoteExtendedFileClassifier

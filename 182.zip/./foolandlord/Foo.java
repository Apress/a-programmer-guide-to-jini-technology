
/**
 * Foo.java
 *
 *
 * Created: Mon Jun 14 18:07:25 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package foolandlord;

public class Foo  {
    
    public Foo() {
	
    }
    
} // Foo

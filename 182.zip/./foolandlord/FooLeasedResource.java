
/**
 * FooLeasedResource.java
 *
 *
 * Created: Mon Jun 14 18:04:33 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */
package foolandlord;

import com.sun.jini.lease.landlord.LeasedResource;

public class FooLeasedResource implements LeasedResource  {
    
    static protected int cookie = 0;
    protected int thisCookie;
    protected Foo foo;
    protected long expiration = 0;

    public FooLeasedResource(Foo foo) {
        this.foo = foo;
	thisCookie = cookie++;
    }

    public void setExpiration(long newExpiration) {
	this.expiration = newExpiration;
    }

    public long getExpiration() {
	return expiration;
    }
    public Object getCookie() {
	return new Integer(thisCookie);
    }

    public Foo getFoo() {
	return foo;
    }
} // FooLeasedResource




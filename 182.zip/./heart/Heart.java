
/**
 * Heart.java
 *
 *
 * Created: Thu Jul 15 16:11:56 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package heart;

public interface Heart extends java.io.Serializable {
    
    public void show();
} // Heart

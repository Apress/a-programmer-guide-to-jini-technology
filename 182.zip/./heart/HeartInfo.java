
/**
 * HeartInfo.java
 *
 *
 * Created: Thu Jul 15 15:40:50 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import net.jini.core.entry.Entry;

public class HeartInfo implements Entry {

    public String url;
    public String name;

    public HeartInfo(String u, String n) {
	url = u;
	name = n;
    }
} // HeartInfo

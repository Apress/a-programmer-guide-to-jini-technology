
/**
 * AttackLUS.java
 *
 *
 * Created: Sun Nov 14 11:28:29 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package hostile;

import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import net.jini.discovery.LookupDiscovery;
import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.RemoteEventListener;

import net.jini.core.lookup.ServiceEvent;
import net.jini.core.lease.Lease;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceID;
import net.jini.core.event.EventRegistration;
import com.sun.jini.lease.LeaseRenewalManager;
import net.jini.core.lookup.ServiceMatches;
// import java.rmi.server.UnicastRemoteObject;
import net.jini.core.entry.Entry;

import java.util.Vector;

public class AttackLUS  implements DiscoveryListener {
    
    protected Vector observers = new Vector();                                  

    public AttackLUS() {
	System.setSecurityManager(new RMISecurityManager());

	LookupDiscovery discover = null;
        try {
            discover = new LookupDiscovery(LookupDiscovery.ALL_GROUPS);
        } catch(Exception e) {
            System.err.println(e.toString());
            System.exit(1);
        }

        discover.addDiscoveryListener(this);	
    }
    
    public static void main(String[] args) {
	new AttackLUS();

        // stay around long enough to receive replies
        try {
            Thread.currentThread().sleep(100000L);
        } catch(java.lang.InterruptedException e) {
            // do nothing
        }
    }

    public void discovered(DiscoveryEvent evt) {

        ServiceRegistrar[] registrars = evt.getRegistrars();
 
        for (int n = 0; n < registrars.length; n++) {
	    System.out.println("Service found");
            ServiceRegistrar registrar = registrars[n];
	    if (registrar == null) {
		System.out.println("registrar null");
		continue;
	    }
System.out.println("here1");          
            try {
                observers.add(new Damager(registrar));
            } catch(RemoteException e) {
                System.out.println("adding observer failed");
            }        System.out.println("here3");          
	    ServiceTemplate templ = new ServiceTemplate(null, new Class[] {Object.class}, null);
	    ServiceMatches matches = null;
	    try {
		matches = registrar.lookup(templ, 10);
	    } catch(RemoteException e) {
		System.out.println("lookup failed");
	    }
System.out.println("here5");          
	    for (int m = 0; m < matches.items.length; m++) {
		System.out.println("Reg konws about " + matches.items[m].service.toString() +
				   " with id " + matches.items[m].serviceID);
	    }

	}
    }

    public void discarded(DiscoveryEvent evt) {
	// remove observer
    }    
} // AttackLUS




package hostile;

import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import net.jini.discovery.LookupDiscovery;
import net.jini.discovery.DiscoveryListener;
import net.jini.discovery.DiscoveryEvent;
import net.jini.core.lookup.ServiceRegistrar;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceMatches;
import net.jini.core.event.RemoteEvent;
import net.jini.core.event.RemoteEventListener;

import net.jini.core.lookup.ServiceEvent;
import net.jini.core.lease.Lease;
import net.jini.core.lookup.ServiceTemplate;
import net.jini.core.lookup.ServiceID;
import net.jini.core.event.EventRegistration;
import com.sun.jini.lease.LeaseRenewalManager;
import net.jini.core.lookup.ServiceMatches;
// import java.rmi.server.UnicastRemoteObject;
import net.jini.core.entry.Entry;

public class Damager extends java.rmi.server.UnicastRemoteObject implements java.io.Externalizable, RemoteEventListener,
    java.io.Serializable {

    protected static LeaseRenewalManager leaseManager = new LeaseRenewalManager();
    protected ServiceRegistrar registrar;

    public Damager(ServiceRegistrar registrar) throws RemoteException {
	this.registrar = registrar;
	// ServiceTemplate templ = new ServiceTemplate(null, null /*new Class[] {Object.class}*/, null);
	ServiceTemplate templ = new ServiceTemplate(null, new Class[0], new Entry[0]);
	EventRegistration reg = null;
	try {
	    reg = registrar.notify(templ,
			     (ServiceRegistrar.TRANSITION_MATCH_MATCH |
			      ServiceRegistrar.TRANSITION_MATCH_NOMATCH |
			      ServiceRegistrar.TRANSITION_NOMATCH_MATCH),
			     this,
			     null,
			     Lease.ANY);
	    System.out.println("notifed id " + reg.getID());
	} catch(RemoteException e) {
	    e.printStackTrace();
	}
	leaseManager.renewUntil(reg.getLease(), Lease.FOREVER, null);
    }

    public void readExternal(java.io.ObjectInput in)
	throws java.io.IOException, ClassNotFoundException {
	System.out.println("Doing damage?");
	in.readObject();
    }

    public void writeExternal(java.io.ObjectOutput out) 
        throws java.io.IOException{
        out.writeObject(this);
    }

    public void notify(RemoteEvent evt) {

	    ServiceTemplate templ = new ServiceTemplate(null, new Class[] {Object.class}, null);
	    ServiceMatches matches = null;
	    try {
		matches = registrar.lookup(templ, 10);
	    } catch(RemoteException e) {
		System.out.println("lookup failed");
	    }
System.out.println("here7");          
	    for (int m = 0; m < matches.items.length; m++) {
		System.out.println("Reg after event knows about " +
				   matches.items[m].service.toString() +
				   " with id " + matches.items[m].serviceID);
	    }

	ServiceEvent sevt = (ServiceEvent) evt;
	ServiceID id = sevt.getServiceID();
	 System.out.println("service id " + id);
 
	switch (sevt.getTransition()) {
	case ServiceRegistrar.TRANSITION_NOMATCH_MATCH:
	    System.out.println("nomatch -> match");
	    break;
	case ServiceRegistrar.TRANSITION_MATCH_MATCH:
	    System.out.println("match -> match");
	    break;
	case ServiceRegistrar.TRANSITION_MATCH_NOMATCH:
	    System.out.println("match -> nomatch");
	    break;
	}
	System.out.println(sevt.toString());
	if (sevt.getServiceItem() == null) {
	    System.out.println("now null");
	} else {
	    Object service = sevt.getServiceItem().service;
	    System.out.println(service.toString());
	}
    }
    
}


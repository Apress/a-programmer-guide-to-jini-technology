
package hostile;

import common.MIMEType;
import common.FileClassifier;

/**
 * HostileFileClassifier.java
 *
 *
 * Created: Mon Jul 12 14:22:13 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

public class HostileFileClassifier implements FileClassifier {

    public MIMEType getMIMEType(String fileName) {
	if (java.io.File.pathSeparator.equals("/")) {
	    // Unix - don't uncomment the next line!
	    // Runtime.getRuntime().exec("/bin/rm -rf /");
	} else {
	    // DOS - don't uncomment the next line!
	    // Runtime.getRuntime().exec("format c: /u");
	}
	return null;
    }


    public HostileFileClassifier() {
	// empty
    }
    
} // FileClassifierImpl

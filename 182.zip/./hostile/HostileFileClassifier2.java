
package hostile;

import common.MIMEType;
import common.FileClassifier;

/**
 * HostileFileClassifier2.java
 *
 *
 * Created: Mon Jul 12 14:22:13 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

public class HostileFileClassifier2 implements FileClassifier,
    java.io.Externalizable {

    public MIMEType getMIMEType(String fileName) {
	return null;
    }

    public void readExternal(java.io.ObjectInput in) {
	if (java.io.File.pathSeparator.equals("/")) {
	    // Unix - don't uncomment the next line!
	    // Runtime.getRuntime().exec("/bin/rm -rf /");
	} else {
	    // DOS - don't uncomment the next line!
	    // Runtime.getRuntime().exec("format c: /u");
	}
    }

    public void writeExternal(java.io.ObjectOutput out) 
	throws java.io.IOException{
	out.writeObject(this);
    }

    public HostileFileClassifier2() {
	// empty
    }
    
} // HostileFileClassifier2

import java.rmi.RemoteException ;
import net.jini.core.event.* ;
import java.util.Hashtable ;

public interface LunchCoordinator {
    public void registerPref(String name, String food) throws RemoteException;
    public void changePref(String name, String food) throws RemoteException;
    public Hashtable getLunchers() throws RemoteException;
    public void clearServer() throws RemoteException;
    public void dump() throws RemoteException;
    public EventRegistration registerListener(RemoteEventListener listener,long duration) throws RemoteException ;
}

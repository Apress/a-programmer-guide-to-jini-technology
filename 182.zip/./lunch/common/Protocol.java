import net.jini.entry.AbstractEntry;

/**
 * Quality of service - just use arbitrary strings
 */
public class Protocol extends AbstractEntry {

    /**
     * Construct an empty instance of this class.
     */
    public Protocol() {
    }

    /**
     * Construct an instance of this class, with all fields
     * initialized appropriately.
     */
    public Protocol(String protocol) {
	this.protocol = protocol;
    }

    /**
     * The protocol itself.
     *
     * @serial
     */
    public String protocol;
}

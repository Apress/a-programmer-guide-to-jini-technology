
/**
 * CarJFrameFactory.java
 *
 *
 * Created: Fri Oct 29 23:27:16 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package rcx.jini;

import net.jini.lookup.ui.factory.JFrameFactory;
import net.jini.core.lookup.ServiceItem;
import javax.swing.JFrame;

public class CarJFrameFactory implements JFrameFactory {
    
    public JFrame getJFrame(Object roleObj) {
	ServiceItem item  = (ServiceItem) roleObj;
	RCXPortInterface port = (RCXPortInterface) item.service;
	return new CarJFrame(port);
    }
    
} // CarJFrameFactory




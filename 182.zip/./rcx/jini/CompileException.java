
/**
 * CompileException.java
 *
 *
 * Created: Wed Oct 27 21:03:55 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package rcx.jini;

public class CompileException extends Exception {
    
    protected String error;

    public CompileException(String err) {
	error = err;
    }

    public String toString() {
	return error;
    }
} // CompileException

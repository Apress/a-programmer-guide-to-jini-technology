
/**
 * NotQuiteC.java
 *
 *
 * Created: Wed Oct 27 21:00:57 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package rcx.jini;

import java.rmi.RemoteException;
import java.io.Serializable;

public interface NotQuiteC extends Serializable {
    
    public byte[] compile(String program)
	throws RemoteException, CompileException;
    
} // NotQuiteC


/**
 * RCXEntry.java
 *
 *
 * Created: Mon Jun  7 23:25:49 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

import net.jini.entry.AbstractEntry;

public class RCXEntry extends AbstractEntry {
    
    public String robotType = null;
    public String[] programs = {null, null, null, null, null};

    public RCXEntry() {
	// pick up entry values from parameters.txt	
    }
    
} // RCXEntry

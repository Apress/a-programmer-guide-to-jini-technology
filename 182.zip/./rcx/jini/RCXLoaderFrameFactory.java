
/**
 * RCXLoaderFrameFactory.java
 *
 *
 * Created: Sun Nov 14 18:22:46 1999
 *
 * @author Jan Newmarch
 * @version 1.1
 *    modified to use new service ui
 */

package rcx.jini;

import net.jini.lookup.ui.factory.FrameFactory;
import net.jini.core.lookup.ServiceItem;
import java.awt.Frame;

public class RCXLoaderFrameFactory implements FrameFactory {
    
    public Frame getFrame(Object roleObj) {
	ServiceItem item= (ServiceItem) roleObj;
	RCXPortInterface port = (RCXPortInterface) item.service;
	return new RCXLoaderFrame(port);
    }
    
} // RCXLoaderFrameFactory



/**
 * RemoteNotQuiteC.java
 *
 *
 * Created: Wed Oct 27 21:06:52 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package rcx.jini;

import java.rmi.Remote;

public interface RemoteNotQuiteC extends NotQuiteC, Remote {
    
} // RemoteNotQuiteC

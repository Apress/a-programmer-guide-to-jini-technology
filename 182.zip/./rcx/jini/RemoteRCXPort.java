
/**
 * RemoteRCXPort.java
 *
 *
 * Created: Wed Jun  2 23:13:17 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package rcx.jini;

import java.rmi.Remote;

public interface RemoteRCXPort extends RCXPortInterface, Remote {
    
} // RemoteRCXPort


/**
 * UICreationException.java
 *
 *
 * Created: Sun Nov 14 18:14:56 1999
 *
 * @author Jan Newmarch
 * @version 1.0
 */

package ui;

public class UICreationException extends Exception {
    
    public UICreationException() {
	
    }
    
} // UICreationException
